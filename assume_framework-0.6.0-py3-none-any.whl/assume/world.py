# SPDX-FileCopyrightText: ASSUME Developers
#
# SPDX-License-Identifier: AGPL-3.0-or-later

import asyncio
import logging
import sys
import time
import warnings
from datetime import datetime
from pathlib import Path

from mango import (
    RoleAgent,
    activate,
    addr,
    agent_composed_of,
    create_ec_container,
    create_mqtt_container,
    create_tcp_container,
)
from mango.container.core import Container
from mango.util.clock import AsyncioClock, ExternalClock
from mango.util.distributed_clock import DistributedClockAgent, DistributedClockManager
from mango.util.termination_detection import tasks_complete_or_sleeping
from sqlalchemy import create_engine, make_url
from sqlalchemy.exc import OperationalError
from tqdm import tqdm

from assume.common import (
    MarketConfig,
    OutputDef,
    UnitsOperator,
    WriteOutput,
    mango_codec_factory,
)
from assume.common.base import LearningConfig
from assume.common.forecaster import UnitForecaster
from assume.common.utils import datetime2timestamp, timestamp2datetime
from assume.markets import MarketRole, clearing_mechanisms
from assume.strategies import (
    LearningStrategy,
    UnitOperatorStrategy,
    bidding_strategies,
    deprecated_bidding_strategies,
)
from assume.units import BaseUnit, demand_side_technologies, unit_types

file_handler = logging.FileHandler(filename="assume.log", mode="w+")
stdout_handler = logging.StreamHandler(stream=sys.stdout)
handlers = [file_handler, stdout_handler]
logging.basicConfig(level=logging.INFO, handlers=handlers)
logging.getLogger("mango").setLevel(logging.WARNING)

logger = logging.getLogger(__name__)


class World:
    """
    Represents a simulation environment with a specified address, database connection, CSV export path,
    log level, and optional distributed role settings.

    If a database URI is provided, the World instance attempts to establish a database connection.
    It initializes key attributes for market operators, markets, unit operators, bidding strategies,
    and clearing mechanisms. Additionally, it checks for learning strategy availability and sets up an event loop.

    Attributes:
        addr (tuple[str, int] | str, optional): The address of the world, represented as a tuple (host, port) or a string.
        distributed_role (bool, optional): Defines the world’s role in distributed execution:
            - `True`: Acts as a manager world that schedules events.
            - `False`: Acts as a client world receiving schedules from a manager.
            - `None` (default): Runs independently without subprocesses.
        export_csv_path (str, optional): Path for exporting CSV data.
        log_level (str, optional): The logging level for the world instance.
        db_uri (sqlalchemy.engine.URL, optional): The processed database URI.
        db (sqlalchemy.engine.base.Engine, optional): The database connection engine.
        container (mango.Container, optional): The container for the world instance.
        loop (asyncio.AbstractEventLoop, optional): The event loop for asynchronous operations.
        clock (Clock, optional): ExternalClock or AsyncioClock instance.
        start (datetime.datetime, optional): Start datetime for the simulation.
        end (datetime.datetime, optional): End datetime for the simulation.
        market_operators (dict[str, mango.RoleAgent], optional): Market operators in the world instance.
        markets (dict[str, MarketConfig], optional): Market configurations.
        unit_operators (dict[str, UnitsOperator], optional): Unit operators.
        unit_types (dict[str, BaseUnit], optional): Available unit types.
        dst_components (dict[str, DemandSideTechnology], optional): Demand-side technologies.
        bidding_strategies (dict[str, type[BaseStrategy]], optional): Bidding strategies for the world instance.
            - If `"powerplant_energy_learning"` is unavailable, learning strategies may be missing due to missing dependencies (e.g., `torch`).
        clearing_mechanisms (dict[str, MarketRole], optional): Market clearing mechanisms.
        additional_kpis (dict[str, OutputDef], optional): Additional performance indicators.
        scenario_data (dict, optional): Dictionary for scenario-specific data.
        addresses (list[str], optional): Addresses for the world instance.
        output_agent_addr (tuple[str, str], optional): Address of the output agent.
        bidding_params (dict, optional): Parameters for bidding.
        index (pandas.Series, optional): The index for simulation tracking.
        learning_config (LearningConfig, optional): Configuration for learning-based components.
        learning_mode (bool, optional): Whether learning mode is enabled.
        evaluation_mode (bool, optional): Whether evaluation mode is enabled.
        forecaster (Forecaster, optional): The forecaster used for custom unit types.

    Args:
        addr (tuple[str, int] | str, optional): The world’s address as a (host, port) tuple or a string. Defaults to `"world"`.
        database_uri (str, optional): Database URI for establishing a connection. Defaults to `""` (no database).
        export_csv_path (str, optional): Path for exporting CSV data. Defaults to `""`.
        log_level (str, optional): Logging level. Defaults to `"INFO"`.
        distributed_role (bool, optional): Defines the world’s role in distributed execution. Defaults to `None`.
    """

    def __init__(
        self,
        addr: tuple[str, int] | str = "world",
        database_uri: str = "",
        export_csv_path: str = "",
        log_level: str = "INFO",
        distributed_role: bool | None = None,
    ) -> None:
        logging.getLogger("assume").setLevel(log_level)
        self.addr = addr
        self.container: Container = None
        self.distributed_role = distributed_role

        self.export_csv_path = export_csv_path
        # initialize db connection at beginning of simulation
        self.db_uri = database_uri
        if database_uri:
            if str(database_uri).startswith("sqlite:///"):
                db_path = Path(str(database_uri).replace("sqlite:///", ""))
                db_path.parent.mkdir(exist_ok=True)
            self.db_uri = make_url(database_uri)
            db = create_engine(self.db_uri)
            connected = False
            attempts = 0
            max_attempts = 5

            while not connected and attempts < max_attempts:
                try:
                    with db.connect():
                        connected = True
                        logger.info("Connected to the database")
                except OperationalError as e:
                    attempts += 1
                    logger.error(
                        "Could not connect to %s, trying again (%d/%d)",
                        database_uri,
                        attempts,
                        max_attempts,
                    )
                    # log error if not connection refused
                    if not e.code == "e3q8":
                        logger.error("%s", e)
                    time.sleep(2**attempts)

            if not connected:
                raise RuntimeError(
                    f"Failed to connect to the database after {max_attempts} attempts"
                )

        self.scenario_data = {}
        self.market_operators: dict[str, RoleAgent] = {}
        self.markets: dict[str, MarketConfig] = {}
        self.unit_operators: dict[str, UnitsOperator] = {}
        self.unit_types = unit_types
        self.dst_components = demand_side_technologies

        self.bidding_strategies = bidding_strategies
        if "powerplant_energy_learning" not in bidding_strategies:
            logger.info(
                "Learning Strategies are not available. Check that you have torch installed."
            )
        self.bidding_strategies.update(deprecated_bidding_strategies)

        self.clearing_mechanisms: dict[str, MarketRole] = clearing_mechanisms
        self.additional_kpis: dict[str, OutputDef] = {}
        self.addresses = []
        # required for jupyter notebooks
        # as they already have a running loop
        import nest_asyncio2

        nest_asyncio2.apply()
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)

    def setup(
        self,
        start: datetime,
        end: datetime,
        simulation_id: str,
        save_frequency_hours,
        bidding_params: dict = {},
        learning_dict: dict = {},
        episode: int = 1,
        eval_episode: int = 1,
        manager_address=None,
        real_time=False,
        **kwargs: dict,
    ) -> None:
        """
        Set up the environment for the simulation, initializing various parameters and components required for the simulation run.

        Args:
            start (datetime.datetime): The start datetime for the simulation.
            end (datetime.datetime): The end datetime for the simulation.
            simulation_id (str): The unique identifier for the simulation.
            save_frequency_hours (int): The frequency (in hours) at which to save simulation data.
            bidding_params (dict, optional): Parameters for bidding. Defaults to an empty dictionary.
            learning_dict (dict, optional): Configuration for the learning process. Defaults to an empty dictionary.
            episode (int, optional): The episode number for learning. Defaults to 1.
            eval_episode (int, optional): The episode number for evaluation. Defaults to 1.
            manager_address: The address of the manager.
            **kwargs: Additional keyword arguments.

        Returns:
            None
        """

        if real_time:
            if manager_address:
                raise Exception("Can't have manager when running realtime")
            if self.distributed_role is not None:
                raise Exception("Can't have distributed role when running realtime")
            self.clock = AsyncioClock()
        else:
            self.clock = ExternalClock(0)
        self.simulation_id = simulation_id
        self.start = start
        self.end = end

        if not learning_dict:
            self.learning_config: LearningConfig = None
        else:
            self.learning_config = LearningConfig(**learning_dict)

        # initiate learning if the learning mode is on and hence we want to learn new strategies
        self.learning_mode = learning_dict.get("learning_mode", False)
        self.evaluation_mode = learning_dict.get("evaluation_mode", False)

        # initialize a config dictionary for the scenario data if not already present
        if not self.scenario_data.get("config"):
            self.scenario_data["config"] = {}

        # make a descriptor for the tqdm progress bar
        # use simulation_id of not in learning mode; use Episode ID if in learning mode
        # and use Evaluation Episode ID if in evaluation mode
        self.simulation_desc = simulation_id

        # update simulation description when learning
        if self.learning_config:
            if self.learning_config.evaluation_mode:
                self.simulation_desc = f"Evaluation Episode {eval_episode}"
            elif self.learning_mode:
                self.simulation_desc = f"Training Episode {episode}"

        self.bidding_params = bidding_params

        # create new container
        container_kwargs = {"mp_method": "fork"} if sys.platform == "linux" else {}
        if self.addr == "world":
            container_func = create_ec_container
            container_kwargs.update({"addr": self.addr})
        elif isinstance(self.addr, tuple):
            container_func = create_tcp_container
            container_kwargs.update({"addr": self.addr})
        else:
            container_func = create_mqtt_container
            container_kwargs = {
                "broker_addr": "localhost",
                "client_id": self.addr,
                "inbox_topic": self.addr,
            }
            container_kwargs.update(**kwargs)

        self.container = container_func(
            codec=mango_codec_factory(),
            clock=self.clock,
            **container_kwargs,
        )

        if not self.db_uri and not self.export_csv_path:
            self.output_agent_addr = None
        else:
            self.output_agent_addr = addr(self.addr, "export_agent_1")

        if self.distributed_role is False:
            # if distributed_role is False - we are a ChildContainer
            # and only connect to the manager_address, which can set/sync our clock
            self.clock_agent = DistributedClockAgent()
            self.output_agent_addr = addr(manager_address, "export_agent_1")

            # # when the clock_agent is stopped, we should gracefully shutdown our container
            # self.clock_agent.stopped.add_done_callback(stop)
            self.container.register(self.clock_agent, suggested_aid="clock_agent")
        else:
            if self.learning_config:
                self.setup_learning(
                    episode=episode,
                    eval_episode=eval_episode,
                )

            self.setup_output_agent(
                save_frequency_hours=save_frequency_hours,
                episode=episode,
                eval_episode=eval_episode,
            )
            self.clock_manager = DistributedClockManager(
                receiver_clock_addresses=self.addresses
            )
            self.container.register(self.clock_manager)

    def setup_learning(self, episode: int, eval_episode: int) -> None:
        """
        Set up the learning process for the simulation, updating bidding parameters with the learning configuration
        and initializing the reinforcement learning (RL) learning role with the specified parameters. It also sets up
        the RL agent and adds the learning role to it for further processing.
        """

        from assume.reinforcement_learning.learning_role import Learning

        # create LearningConfig object
        self.learning_role = Learning(
            learning_config=self.learning_config, start=self.start, end=self.end
        )

        if self.learning_config.learning_mode or self.learning_config.evaluation_mode:
            # if so, we initiate the rl learning role with parameters
            rl_agent = agent_composed_of(
                self.learning_role,
                register_in=self.container,
                suggested_aid="learning_agent",
            )
            rl_agent.suspendable_tasks = False

            self.learning_role.init_logging(
                simulation_id=self.simulation_id,
                episode=episode,
                eval_episode=eval_episode,
                db_uri=self.db_uri,
                output_agent_addr=self.output_agent_addr,
                train_start=self.start,
            )

    def setup_output_agent(
        self,
        save_frequency_hours: int,
        episode: int,
        eval_episode: int,
    ) -> None:
        """
        Set up the output agent for the simulation, creating an output role responsible for writing simulation output,
        including data storage and export settings. Depending on the platform (currently supported only on Linux),
        it adds the output agent to the container's processes, or directly adds the output role to the output agent.

        Args:
            save_frequency_hours (int): The frequency (in hours) at which to save simulation data.
        """

        logger.debug(
            "creating output agent db=%s export_csv_path=%s",
            self.db_uri,
            self.export_csv_path,
        )
        self.output_role = WriteOutput(
            simulation_id=self.simulation_id,
            start=self.start,
            end=self.end,
            db_uri=self.db_uri,
            export_csv_path=self.export_csv_path,
            save_frequency_hours=save_frequency_hours,
            learning_mode=self.learning_mode,
            evaluation_mode=self.evaluation_mode,
            episode=episode,
            eval_episode=eval_episode,
            additional_kpis=self.additional_kpis,
            outputs_buffer_size_mb=self.scenario_data["config"].get(
                "outputs_buffer_size_mb", 300
            ),
        )
        if not self.output_agent_addr:
            return

        # mango multiprocessing is currently only supported on linux
        # with single
        if sys.platform == "linux" and self.distributed_role is not None:
            self.addresses.append(addr(self.addr, "clock_agent"))
            output_role = self.output_role
            output_aid = self.output_agent_addr.aid

            def creator(container):
                agent = agent_composed_of(
                    output_role,
                    register_in=container,
                    suggested_aid=output_aid,
                )
                agent.suspendable_tasks = False
                container.register(DistributedClockAgent(), "clock_agent")

            self.container.as_agent_process_lazy(agent_creator=creator)
        else:
            output_agent = agent_composed_of(
                self.output_role,
                register_in=self.container,
                suggested_aid=self.output_agent_addr.aid,
            )
            output_agent.suspendable_tasks = False

    def add_unit_operator(
        self, id: str, strategies: dict[str, UnitOperatorStrategy] = {}
    ) -> None:
        """
        Add a unit operator to the simulation, creating a new role agent and applying the role of a unit operator to it.
        The unit operator is then added to the list of existing operators. Unit operator receives the output agent address
        if not in learning mode.

        Args:
            id (str): The identifier for the unit operator.
        """

        if self.unit_operators.get(id):
            raise ValueError(f"Unit operator {id} already exists")

        # Strategies must reference existing markets.
        for market_id in strategies.keys():
            if market_id not in list(self.markets.keys()):
                msg = (
                    f"Strategies of unit operator {id} references "
                    f"market {market_id} which is not known in world.\n"
                    f"Known markets are: {list(self.markets.keys())}.\n"
                    f"Note: Markets must be added before unit operators."
                )
                warnings.warn(msg)

        bidding_strategies = self._prepare_bidding_strategies(
            {"bidding_strategies": strategies}, id
        )

        units_operator = UnitsOperator(
            available_markets=list(self.markets.values()),
            portfolio_strategies=bidding_strategies,
        )

        # creating a new role agent and apply the role of a units operator
        unit_operator_agent = RoleAgent()
        unit_operator_agent.add_role(units_operator)
        self.container.register(unit_operator_agent, suggested_aid=str(id))
        unit_operator_agent.suspendable_tasks = False

        # add the current unitsoperator to the list of operators currently existing
        self.unit_operators[id] = units_operator

        # after creation of an agent - we set additional context params
        if not self.learning_mode:
            unit_operator_agent._role_context.data.update(
                {
                    "output_agent_addr": self.output_agent_addr,
                }
            )

    def add_units_with_operator_subprocess(
        self, id: str, units: list[dict], strategies: dict[str, UnitOperatorStrategy]
    ):
        """
        Adds a units operator with given ID in a separate process
        and creates and adds the given list of unit dictionaries to it
        through a creator function

        Args:
            id (str): the id of the units operator
            units (list[dict]): list of unit dictionaries forwarded to create_unit
        """
        clock_agent_name = f"clock_agent_{id}"
        markets = list(self.markets.values())
        for market in markets:
            # remove generator from rrule as it is not serializable
            if market.opening_hours._cache is not None:
                market.opening_hours._cache = None
                market.opening_hours._cache_complete = False
                market.opening_hours._cache_gen = None
        self.addresses.append(addr(self.addr, clock_agent_name))
        units_operator = UnitsOperator(
            available_markets=markets, portfolio_strategies=strategies
        )

        for unit in units:
            units_operator.add_unit(self.create_unit(**unit))
        data_update_dict = {
            "output_agent_addr": self.output_agent_addr,
        }

        def creator(container):
            # creating a new role agent and apply the role of a units operator

            unit_operator_agent = agent_composed_of(
                units_operator, register_in=container, suggested_aid=str(id)
            )
            unit_operator_agent.suspendable_tasks = False
            unit_operator_agent._role_context.data.update(data_update_dict)
            container.register(DistributedClockAgent(), suggested_aid=clock_agent_name)

        self.container.as_agent_process_lazy(agent_creator=creator)

    def create_unit(
        self,
        id: str,
        unit_type: str,
        unit_operator_id: str,
        unit_params: dict,
        forecaster: UnitForecaster,
    ) -> BaseUnit:
        # provided unit type does not exist yet
        unit_class: type[BaseUnit] = self.unit_types.get(unit_type)

        bidding_strategies = self._prepare_bidding_strategies(unit_params, id)
        # if we have learning strategy we need to assign the powerplant to one unit_operator handling all learning units
        unit_params["bidding_strategies"] = bidding_strategies

        # create unit within the unit operator its associated with
        return unit_class(
            id=id,
            unit_operator=unit_operator_id,
            forecaster=forecaster,
            **unit_params,
        )

    def _prepare_bidding_strategies(self, unit_params, unit_id):
        """
        Prepare bidding strategies for the unit based on the specified parameters.

        Args:
            unit_params (dict): Parameters for configuring the unit.
            unit_id (str): The identifier for the unit.

        Returns:
            dict[str, BaseStrategy | UnitOperatorStrategy]: The bidding strategies for the unit.
        """
        bidding_strategies = {}
        strategy_instances = {}  # Cache to store created instances

        # Extract bidding parameters outside the loop
        bidding_params = unit_params.get("bidding_params", self.bidding_params)

        for market_id, strategy in unit_params["bidding_strategies"].items():
            if not strategy:
                continue

            if strategy not in self.bidding_strategies:
                # raise a deprecated warning for learning_advanced_orders
                raise ValueError(
                    f"""Bidding strategy {strategy} not registered. Please check the name of
                        the bidding strategy or register the bidding strategy in the world.bidding_strategies dict."""
                )

            # remove when deprecated bidding strategies are removed
            if strategy in deprecated_bidding_strategies.keys():
                logger.warning(
                    "Bidding strategy %s is deprecated. Use the new naming instead",
                    strategy,
                )

            if strategy not in strategy_instances:
                # check if created cache has learning_strategy
                if issubclass(self.bidding_strategies[strategy], LearningStrategy):
                    # add learning role to the strategy to have access to store training data etc
                    if self.learning_config is None:
                        raise ValueError(
                            f"Learning strategy '{strategy}' requires a configured 'learning_config', but none was set. "
                            "Specify learning_config in config.yaml."
                        )
                    strategy_instances[strategy] = self.bidding_strategies[strategy](
                        unit_id=unit_id,
                        learning_role=self.learning_role,
                        **bidding_params,
                    )
                else:
                    # Create and cache the strategy instance if not already created
                    strategy_instances[strategy] = self.bidding_strategies[strategy](
                        unit_id=unit_id,
                        **bidding_params,
                    )

            # Use the cached instance for this market
            bidding_strategies[market_id] = strategy_instances[strategy]

        return bidding_strategies

    def _validate_unit_addition(self, id, unit_type, unit_operator_id):
        """
        Validate the addition of a unit to the simulation, checking if the unit operator and unit type exist,
        and ensuring that the unit does not already exist.

        Args:
            id (str): The identifier for the unit.
            unit_type (str): The type of the unit.
            unit_operator_id (str): The identifier of the unit operator.
        """

        self._validate_unit_operator(unit_operator_id)

        if unit_type not in self.unit_types:
            raise ValueError(f"Invalid unit type: {unit_type}")

        if self.unit_operators[unit_operator_id].units.get(id):
            raise ValueError(f"Unit {id} already exists")

    def _validate_unit_operator(self, unit_operator_id: str):
        """
        Validate the existence of a unit operator in the simulation.

        Args:
            unit_operator_id (str): The identifier for the unit operator.
        """

        if unit_operator_id not in self.unit_operators.keys():
            raise ValueError(f"Invalid unit operator: {unit_operator_id}")

    def add_market_operator(self, id: str) -> None:
        """
        Add a market operator to the simulation by creating a new role agent for the market operator
        and setting additional context parameters. If not in learning mode and not in evaluation mode,
        it includes the output agent address and ID in the role context data dictionary.

        Args:
            id (str): The identifier for the market operator.
        """

        if self.market_operators.get(id):
            raise ValueError(f"MarketOperator {id} already exists")
        market_operator_agent = RoleAgent()
        self.container.register(market_operator_agent, suggested_aid=id)
        market_operator_agent.suspendable_tasks = False
        market_operator_agent.markets = []

        # after creation of an agent - we set additional context params
        if not self.learning_mode and not self.evaluation_mode:
            market_operator_agent._role_context.data.update(
                {"output_agent_addr": self.output_agent_addr}
            )
        self.market_operators[id] = market_operator_agent

    def add_market(self, market_operator_id: str, market_config: MarketConfig) -> None:
        """
        Add a market to the simulation by creating a market role based on the specified market mechanism in the market
        configuration. Then, add this role to the specified market operator and append the market configuration to the list
        of markets within the market operator. Additionally, store the market configuration in the simulation's markets dictionary.

        Args:
            market_operator_id (str): The identifier of the market operator to which the market will be added.
            market_config (MarketConfig): The configuration for the market to be added.

        Returns:
            None
        """

        if mm_class := self.clearing_mechanisms.get(market_config.market_mechanism):
            market_role = mm_class(market_config)
        else:
            raise Exception(
                f"invalid {market_config.market_mechanism=} - full version installed?"
            )

        market_operator = self.market_operators.get(market_operator_id)

        if not market_operator:
            raise Exception(f"invalid {market_operator_id=}")

        market_start = market_config.opening_hours[0]
        market_end = market_config.opening_hours[-1]

        if market_start < self.start or market_end > self.end:
            msg = (
                f"Market {market_config.market_id} violates world schedule. \n"
                f"Market start: {market_start}, end: {market_end}. \n)"
                f"World start: {self.start}, end: {self.end}.)"
            )
            raise ValueError(msg)

        market_operator.add_role(market_role)
        market_operator.markets.append(market_config)
        self.markets[f"{market_config.market_id}"] = market_config

    def _validate_setup(self):
        """Validate the consistency of the world configuration and fail early."""

        # For each UnitOperator: Strategies must reference existing markets.
        unit_operators = list(self.unit_operators.values())
        for operator in unit_operators:
            for market_id in operator.portfolio_strategies.keys():
                if market_id not in list(self.markets.keys()):
                    msg = (
                        f"Strategies of unit operator {operator} references"
                        f"market {market_id} which is not known in world."
                        f"Known markets are:\n{list(self.markets.keys())}."
                    )
                    raise ValueError(msg)

        # For each market: Should be referenced by a market strategy.
        referenced_markets = {
            market
            for market in operator.portfolio_strategies.keys()
            for operator in unit_operators
        }
        for market_id in self.markets.keys():
            if market_id not in referenced_markets:
                msg = f"Added market {market_id}, has no bidding participants."
                warnings.warn(msg)

        # A Re-Dispatch market can only open if an earlier market closed.
        dispatch_markets = [
            config
            for config in self.markets.values()
            if config.market_mechanism != "redispatch"
        ]
        redispatch_markets = [
            config
            for config in self.markets.values()
            if config.market_mechanism == "redispatch"
        ]

        if len(redispatch_markets) > 0:
            if len(dispatch_markets) == 0:
                msg = "Redispatch market but no dispatch market was defined."
                raise ValueError(msg)

            # when will market result be available from dispatch market
            earliest_dispatch_closing = min(
                x.opening_hours[0] + x.opening_duration for x in dispatch_markets
            )
            # opening of redispatch market
            earliest_redispatch_opening = min(
                x.opening_hours[0] for x in redispatch_markets
            )

            if earliest_redispatch_opening < earliest_dispatch_closing:
                msg = (
                    "First redispatch market opens before first dispatch "
                    "market has closed."
                )
                raise ValueError(msg)

        # Existence of demand implies existence of generation and vice versa.
        demand_exists, generation_exists = False, False

        demand_types = [self.unit_types[x] for x in ["demand"]]
        generation_types = [
            self.unit_types[x] for x in ["power_plant", "hydrogen_plant"]
        ]

        for operator in unit_operators:
            for unit in operator.units.values():
                if type(unit) in demand_types:
                    demand_exists = True
                elif type(unit) in generation_types:
                    generation_exists = True

        if demand_exists and not generation_exists:
            msg = (
                f"Demand units but no generation units were created.\n"
                f"Known generation types are: {generation_types}.\n"
                f"This indicates an incomplete simulation setup."
            )
            warnings.warn(msg)
        elif generation_exists and not demand_exists:
            msg = (
                f"Generation units but no demand units were created.\n"
                f"Known demand types are: {demand_types}.\n"
                f"This indicates an incomplete simulation setup."
            )
            warnings.warn(msg)

    async def _step(self, container):
        """
        Executes a simulation step for the container.
        Manages distribution of time using the clock_manager.
        Waits for completion or sleeping of active tasks before returning the schedule.

        Args:
            container (mango.Container): the container which should be awaited

        Returns:
            float: the time delta since the last activity in seconds
        """
        if self.distributed_role:
            # TODO find better way than sleeping
            # we need to wait, until the last step is executed correctly
            await asyncio.sleep(0.04)
        if self.distributed_role is not False:
            next_activity = await self.clock_manager.distribute_time()
        else:
            next_activity = self.clock.get_next_activity()
        if not next_activity:
            logger.info("simulation finished - no schedules left")
            return None
        delta = next_activity - self.clock.time
        self.clock.set_time(next_activity)
        await tasks_complete_or_sleeping(container)
        return delta

    async def async_run(self, start_ts: datetime, end_ts: datetime):
        """
        Run the simulation asynchronously, progressing the simulation time from the start timestamp to the end timestamp,
        allowing registration before the first opening. If distributed roles are enabled, broadcast the simulation time.
        Iterate through the simulation time, updating the progress bar and the simulation description. Once the simulation
        time reaches the end timestamp, close the progress bar and shut down the simulation container.

        Args:
            start_ts (datetime.datetime): The start timestamp for the simulation run.
            end_ts (datetime.datetime): The end timestamp for the simulation run.
        """
        self._validate_setup()

        logger.debug("activating container")
        # agent is implicit added to self.container._agents
        async with activate(self.container) as c:
            await tasks_complete_or_sleeping(c)
            logger.debug("all agents up - starting simulation")

            pbar = tqdm(total=end_ts - start_ts)

            if isinstance(self.clock, ExternalClock):
                # allow registration before first opening
                self.clock.set_time(start_ts - 1)
                if self.distributed_role is not False:
                    await self.clock_manager.broadcast(self.clock.time)
                prev_delta = 0
                while self.clock.time < end_ts:
                    await asyncio.sleep(0)
                    delta = await self._step(c)
                    if delta or prev_delta:
                        pbar.update(delta)
                        pbar.set_description(
                            f"{self.simulation_desc} {timestamp2datetime(self.clock.time)}",
                            refresh=False,
                        )
                    else:
                        self.clock.set_time(end_ts)
                    prev_delta = delta
            else:
                # real-time mode
                while self.clock.time < end_ts:
                    time = self.clock.time
                    await asyncio.sleep(1)
                    delta = self.clock.time - time
                    pbar.update(delta)
            pbar.close()

    def run(self):
        """
        Run the simulation.

        This method converts the start and end timestamps to UTC time and then runs the asynchronous simulation using
        the `async_run` method. It progresses the simulation time from the start timestamp to the end timestamp, allowing
        registration before the first opening. If distributed roles are enabled, it broadcasts the simulation time. The
        method then iterates through the simulation time, updating the progress bar and the simulation description. Once
        the simulation time reaches the end timestamp, the method closes the progress bar and shuts down the simulation
        container.
        """

        start_ts = datetime2timestamp(self.start)
        end_ts = datetime2timestamp(self.end)

        try:
            return self.loop.run_until_complete(
                self.async_run(start_ts=start_ts, end_ts=end_ts)
            )
        except KeyboardInterrupt:
            pass

    def reset(self):
        """
        Reset the market operators, markets, unit operators, and forecast providers to empty dictionaries.

        Returns:
            None
        """
        self.market_operators = {}
        self.markets = {}
        self.unit_operators = {}
        self.forecast_providers = {}

    def add_unit(
        self,
        id: str,
        unit_type: str,
        unit_operator_id: str,
        unit_params: dict,
        forecaster: UnitForecaster,
    ) -> None:
        """
        Creates a unit and adds it to the World instance.

        This method checks if the unit operator exists, verifies the unit type, and ensures that the unit operator
        does not already have a unit with the same id. It then creates bidding strategies for the unit and creates
        the unit within the associated unit operator.

        Args:
            id (str): The identifier for the unit.
            unit_type (str): The type of the unit.
            unit_operator_id (str): The identifier of the unit operator.
            unit_params (dict): Parameters specific to the unit.
            forecaster (Forecaster): The forecaster associated with the unit.
        """

        # check if unit operator exists
        self._validate_unit_addition(id, unit_type, unit_operator_id)

        unit = self.create_unit(
            id, unit_type, unit_operator_id, unit_params, forecaster
        )

        self.unit_operators[unit_operator_id].add_unit(unit)

    def add_unit_instance(self, operator_id: str, unit: BaseUnit):
        """
        Add an existing unit to the World instance.

        This method checks if the unit operator exists and then assigns the provided unit instance to it.

        Args:
            operator_id (str): The identifier of the unit operator.
            unit (BaseUnit): The unit instance to be added.
        """
        self._validate_unit_operator(operator_id)
        self.unit_operators[operator_id].add_unit(unit)
